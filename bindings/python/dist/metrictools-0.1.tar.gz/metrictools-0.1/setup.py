from distutils.core import setup
setup(
  name = 'metrictools',
  packages = ['metrictools'],
  version = '0.1',
  description = 'metrictools python binding',
  author = 'Paul Asmuth',
  author_email = 'paul@asmuth.com',
  url = 'https://github.com/paulasmuth/metrictools',
  download_url = 'https://github.com/paulasmuth/metrictools/tarball/0.1',
  keywords = ['metrictools']
)
